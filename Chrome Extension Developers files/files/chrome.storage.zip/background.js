chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension Installed.");
    // chrome.storage.session.setAccessLevel({ accessLevel: "ALWAYS" });
});
