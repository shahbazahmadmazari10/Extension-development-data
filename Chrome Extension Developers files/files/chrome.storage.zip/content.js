// chrome.storage.session.get("key", (data) => {
//     console.log("Content Script Access:", data.key || "No Access");


// });


window.onload = () => {
    const btn = document.createElement("button");
    btn.innerText = 'Change Sync Storage';
    btn.addEventListener("click", () => {

        chrome.storage.sync.set({ key: getRandomNumber() })
        // chrome.storage.local.set({ key: getRandomNumber() })
    })
    document.body.appendChild(btn)

    const btn2 = document.createElement("button");
    btn2.innerText = 'Change local Storage';
    btn2.addEventListener("click", () => {

        // chrome.storage.sync.set({ key: getRandomNumber() })
        chrome.storage.local.set({ key: getRandomNumber() })
    })
    document.body.appendChild(btn2)

    
    


}
function getRandomNumber() {
    return Math.floor(Math.random() * 1000) + 1;
}




chrome.storage.onChanged.addListener((changes, areaName) => {
    console.log(changes);
    console.log(areaName);
    if (areaName === 'sync') {
        console.log('Changes in chrome.storage.sync:', changes);

        for (let key in changes) {
            let storageChange = changes[key];
            // console.log(`Key: ${key}, Old Value: ${storageChange.oldValue}, New Value: ${storageChange.newValue}`);
            // syncData.textContent = storageChange.newValue
            document.querySelector('#syncData')?.remove()
            const div = document.createElement('div')
            div.id = 'syncData'
            div.innerText = "Sync " + storageChange.newValue
            // div.id = 'testing'
            div.style.width = '100%'
            div.style.height = '100%'
            div.style.fontSize = '100px'
            document.body.appendChild(div)
        }
    }
    else if (areaName === 'local') {
        console.log('Changes in chrome.storage.sync:', changes);

        for (let key in changes) {
            let storageChange = changes[key];
            // console.log(`Key: ${key}, Old Value: ${storageChange.oldValue}, New Value: ${storageChange.newValue}`);
            // syncData.textContent = storageChange.newValue
            document.querySelector('#localData')?.remove()
            const div = document.createElement('div')
            div.id = 'localData'
            div.innerText = "local " + storageChange.newValue
            // div.id = 'testing'
            div.style.width = '100%'
            div.style.height = '100%'
            div.style.fontSize = '100px'
            document.body.appendChild(div)
        }
    }
});

