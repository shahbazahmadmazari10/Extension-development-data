document.addEventListener("DOMContentLoaded", function () {
    const input = document.getElementById("dataInput");
    const localData = document.getElementById("localData");
    const sessionData = document.getElementById("sessionData");
    const syncData = document.getElementById("syncData");

    // Save to local storage
    document.getElementById("saveLocal").addEventListener("click", async () => {

        await chrome.storage.local.set({ key: input.value })

        console.log("Saved to Local Storage.");
        displayStoredData();

    });

    // Save to session storage
    document.getElementById("saveSession").addEventListener("click", () => {
        chrome.storage.session.set({ key: input.value }, () => {
            console.log("Saved to Session Storage.");
            displayStoredData();
        });
    });

    // Save to sync storage
    document.getElementById("saveSync").addEventListener("click", () => {
        chrome.storage.sync.set({ key: input.value }, () => {
            console.log("Saved to Sync Storage.");
            displayStoredData();
        });
    });

    // Clear all storage
    document.getElementById("clearStorage").addEventListener("click", () => {
        chrome.storage.local.clear();
        chrome.storage.session.clear();
        chrome.storage.sync.clear();
        console.log("All storage cleared.");
        displayStoredData();
    });

    // Display stored data
    function displayStoredData() {
        chrome.storage.local.get("key", (data) => {
            localData.textContent = data.key || "No Data";
        });

        chrome.storage.session.get("key", (data) => {
            sessionData.textContent = data.key || "No Data";
        });

        chrome.storage.sync.get("key", (data) => {
            syncData.textContent = data.key || "No Data";
        });
    }

    chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'sync') {
            console.log('Changes in chrome.storage.sync:', changes);

            for (let key in changes) {
                let storageChange = changes[key];
                // console.log(`Key: ${key}, Old Value: ${storageChange.oldValue}, New Value: ${storageChange.newValue}`);
                syncData.textContent = storageChange.newValue
            }
        }
    });

    

    displayStoredData();
});
