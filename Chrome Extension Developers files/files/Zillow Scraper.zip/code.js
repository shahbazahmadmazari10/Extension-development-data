async function jsonToCsv(jsonData) {

    const blob = new Blob([jsonData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'data.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }


}

function scrollToElement(element) {
    element?.scrollIntoView({
        behavior: "smooth",
        block: "start"
    });
}

async function wait(sec) {
    await new Promise((rs, rj) => setTimeout(rs, 1000 * sec))
}

const simulateMouseFocus = (element) => {
    ['mousedown', 'click', 'focus'].forEach(mouseEventType =>
        element.dispatchEvent(
            new MouseEvent(mouseEventType, {
                view: window,
                bubbles: true,
                cancelable: true,
                buttons: 1
            })
        )
    );
};


// Function to call when the loading message is removed
function onLoadingMessageRemoved() {
    console.log("Loading message removed!");
    // Add your logic here
}

// Select the target node
const targetNode = document.getElementById("grid-search-results");

if (targetNode) {
    const observer = new MutationObserver((mutationsList) => {
        mutationsList.forEach((mutation) => {
            if (mutation.type === "childList") {
                // Check for added nodes
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1 && node.classList.contains("list-loading-message-cover")) {
                        console.log("Loading message added.");
                        node.dataset.observed = "true"; // Mark for tracking
                    }
                });

                // Check for removed nodes
                mutation.removedNodes.forEach((node) => {
                    if (node.nodeType === 1 && node.classList.contains("list-loading-message-cover") && node.dataset.observed) {
                        console.log("Loading message removed.");
                        onLoadingMessageRemoved();
                    }
                });
            }
        });
    });

    // Start observing the target node
    observer.observe(targetNode, { childList: true, subtree: true });

    console.log("MutationObserver started.");
} else {
    console.error("Element #grid-search-results not found.");
}


function deleteAllCookies() {
    document.cookie.split(";").forEach(cookie => {
        let [name] = cookie.split("=");
        document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    });
}

deleteAllCookies();