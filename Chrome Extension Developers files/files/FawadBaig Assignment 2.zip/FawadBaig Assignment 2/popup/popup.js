document.addEventListener('DOMContentLoaded', function () {
    const countElement = document.getElementById('countDisplay');
    const incrementButton = document.getElementById('btnIncreamentCount');
    const clearBadgeButton = document.getElementById('btnClearBadge');
    const resetCountButton = document.getElementById('btnResetCount');
  
    // Update the displayed count
    function updateCountDisplay(count) {
      countElement.textContent = count;
    }
  
    // Get the current count from storage
    chrome.storage.local.get(['count'], function (result) {
      const count = result.count || 0;
      updateCountDisplay(count);
    });
  
    // Increment count
    incrementButton.addEventListener('click', function () {
      chrome.storage.local.get(['count'], function (result) {
        let count = result.count || 0;
        count++;
        chrome.storage.local.set({ count: count }, function () {
          chrome.runtime.sendMessage({ action: 'updateBadge', count: count });
          updateCountDisplay(count);
        });
      });
    });
  
    // Clear badge
    clearBadgeButton.addEventListener('click', function () {
      chrome.runtime.sendMessage({ action: 'clearBadge' });
      updateCountDisplay(0);
    });
  
    // Reset count to default
    resetCountButton.addEventListener('click', function () {
      chrome.storage.local.set({ count: 0 }, function () {
        chrome.runtime.sendMessage({ action: 'resetBadge' });
        updateCountDisplay(0);
      });
    });
  });
  