function getRandomColor() {
    const randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
    return randomColor;
}

chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension is Installed!");
    chrome.storage.local.set({ count: 0 });
    setTimeout(() => {
        chrome.action.setBadgeText({text: "FD"});
        chrome.action.setBadgeTextColor({color: "yellow"});
        chrome.action.setBadgeBackgroundColor({color: getRandomColor()});
        var count = 0;
    },5000);
});

chrome.runtime.onMessage.addListener(function (message, sendResponse){
    if(message.action === "updateBadge"){
        const count = message.count;
        chrome.action.setBadgeText({text: count.toString()});

        let color = "#4CAF50";
        if(count > 5 && count <= 10){
            color = '#FF9800';
        }
        else if (count > 10) {
            color = "#F44336";
        }
        chrome.action.setBadgeBackgroundColor({color: color});
    }
    else if (message.action === "clearBadge") {
        chrome.action.setBadgeText({text: ""});
        chrome.action.setBadgeBackgroundColor({color: "#FFFFFF"});
    }
    else if (message.action === "resetBadge") {
        chrome.action.setBadgeBackgroundColor({color: "green"});
        chrome.action.setBadgeText({text: "FD"});
        chrome.action.setBadgeTextColor({color: "yellow"});
    }
});
