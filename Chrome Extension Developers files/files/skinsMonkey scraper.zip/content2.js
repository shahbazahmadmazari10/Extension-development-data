(async () => {
    let scroll = undefined,
        scroll2 = undefined,
        startP = 0,
        end = 500,
        step = 500;

    localStorage.setItem('status', JSON.stringify(false));
    monkeyPatch();
    console.log('loaded');

    // window.onload = async () => {
    await checkUnit('[type="SITE"][class="inventory-toolbar"]')

    const toolbar = document.querySelector('[data-inventory="SITE"][class="trade-inventory"]')

    const newDiv = document.createElement('div')
    newDiv.id = 'extension_div'
    newDiv.innerHTML = `
            <div style="width:80%">
                  <div class="row">
                    <div class="col-md-12">
            
                        <div class="button_field">
                            <button id="start_button" class="button-37">Start Scraping</button>
                            <button id="stop_button" class="button-37" disabled>Stop</button>
                        </div>
                        <div>
                            <button id="download_button" class="button-37">Download CSV</button>
                        </div>
        
                         <fieldset>
            
                            <div style="margin-bottom: 5px;margin-top:10px;color:white">
                                <span style="font-size:medium;"> <span id="text" style="font-size:medium;">Successfully Scraped Data
                                    </span> <span id="success">0</span></span>
                            </div>
                        </fieldset>
            
                        <!-- </form> -->
                    </div>
                </div>
                </div>
                `
    if (toolbar.children.length > 1) {

        toolbar.insertBefore(newDiv, toolbar.children[1]);
    } else {

        toolbar.appendChild(newDiv);
    }

    // }

    popupJS()


    function popupJS() {
        const status = JSON.parse(localStorage.getItem('status')) || false;

        if (status) {
            document.querySelector('#start_button').setAttribute('disabled', true);
            document.querySelector('#stop_button').removeAttribute('disabled');
        } else {
            document.querySelector('#start_button').removeAttribute('disabled');
            document.querySelector('#stop_button').setAttribute('disabled', true);
        }

        setInterval(() => {
            const status = JSON.parse(localStorage.getItem('status')) || false;
            if (status) {
                const count = JSON.parse(localStorage.getItem('count')) || 0;
                document.getElementById("success").innerText = count;
            }
        }, 500);


        document.querySelector('#start_button').addEventListener('click', () => {
            console.log('click');

            localStorage.setItem('count', JSON.stringify(0));
            localStorage.setItem('fullCount', JSON.stringify(0));
            localStorage.setItem('status', JSON.stringify(true));

            document.querySelector('#start_button').setAttribute('disabled', true);
            document.querySelector('#stop_button').removeAttribute('disabled');
            console.log('get Current Data');
            console.log(currentData);
            getData(currentData)
            scroll = setInterval(() => {
                document.querySelectorAll('.trade-inventory .inventory-grid .scrollable-content__body')[1]?.scrollTo(startP, end);
                startP += step;
                end += step;
            }, 500);

            scroll2 = setInterval(() => {
                document.querySelectorAll('.trade-inventory .inventory-grid .scrollable-content__body')[1]?.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });;
                startP += step;
                end += step;
            }, 5000);



        });

        document.querySelector('#stop_button').addEventListener('click', (e) => {
            console.log('stopped clicked');
            e.target.setAttribute('disabled', true);
            document.querySelector('#start_button').removeAttribute('disabled');

            localStorage.setItem('status', JSON.stringify(false));

            jsonToCsv();

            clearInterval(scroll)
            clearInterval(scroll2)
            setTimeout(() => {
                totalData = [];
                startP = 0;
                end = 100;
                step = 100;
                localStorage.setItem('status', JSON.stringify(false));
                localStorage.setItem('fullData', JSON.stringify([]));
                localStorage.setItem('count', JSON.stringify(0));
                document.getElementById("success").innerText = '0'
            }, 1000);

        });

        document.querySelector('#download_button').addEventListener('click', () => {
            jsonToCsv();
        });
    }





    let totalData = [];
    let currentData = undefined

    function getData(data) {
        data = data.assets;
        const status = JSON.parse(localStorage.getItem('status'));
        console.log(status);
        console.log(data);
        if (status) {
            for (let item = 0; item < data.length; item++) {
                let itemData = {};
                const variantName = data[item].item.details.variantName;
                const weapon = data[item].item.details.weapon;
                const rarity = data[item].item.details.rarity;
                const type = data[item].item.details.type;
                const skin = data[item].item.details.skin;
                const exterior = data[item].item.details.exterior;
                const marketName = data[item].item.marketName;
                const price = convertToDollars(Number(data[item].item.price));
                const tradeLockTime = convertToTime(Number(data[item].tradeLockTime));
                const patternValue = data[item].game730.paintSeed;
                const floatValue = data[item].game730.paintWear;
                const finishValue = data[item].game730.paintIndex;

                itemData = {
                    variantName,
                    weapon,
                    type,
                    skin,
                    exterior,
                    marketName,
                    price,
                    tradeLockTime,
                    patternValue,
                    floatValue,
                    finishValue,
                    rarity
                };

                const stickers = data[item].game730.stickers;
                if (stickers.length > 0) {
                    for (let sticker = 0; sticker < stickers.length; sticker++) {
                        itemData[`Sticker${sticker + 1} Position`] = stickers[sticker]?.index + 1 || '';
                        itemData[`Sticker${sticker + 1} Price`] = convertToDollars(Number(stickers[sticker].price));
                        itemData[`Sticker${sticker + 1} Name`] = stickers[sticker].marketName;
                        itemData[`Sticker${sticker + 1} wear`] = stickers[sticker].wear;
                    }
                }

                const keychains = data[item].game730.keychains;
                if (keychains.length > 0) {
                    for (let keychain = 0; keychain < keychains.length; keychain++) {
                        itemData[`Charm${keychain + 1} Position`] = keychains[keychain]?.index + 1 || ''
                        itemData[`Charm${keychain + 1} Price`] = convertToDollars(Number(keychains[keychain].price));
                        itemData[`Charm${keychain + 1} Name`] = keychains[keychain].marketName;
                        itemData[`Charm${keychain + 1} wear`] = keychains[keychain].wear;
                        itemData[`Charm${keychain + 1} pattern`] = keychains[keychain].patterns;
                    }
                }

                // console.table(itemData);
                totalData.push(itemData);
            }

            console.log(totalData);
            console.table(totalData);
            localStorage.setItem('count', JSON.stringify(totalData.length));
            localStorage.setItem('fullData', JSON.stringify(totalData));
        }

    }


    function monkeyPatch() {
        console.log('called');
        'use strict';

        const originalOpen = XMLHttpRequest.prototype.open;
        const originalSend = XMLHttpRequest.prototype.send;

        XMLHttpRequest.prototype.open = function (method, url) {
            this._method = method;
            this._url = url;
            return originalOpen.apply(this, arguments);
        };

        let currentURL = ''
        XMLHttpRequest.prototype.send = function (body) {
            this.addEventListener('readystatechange', function () {
                if (this.readyState === XMLHttpRequest.DONE && this._url) {
                    const urlPattern = /\/api\/inventory\?limit=\d+&offset=\d+&appId=\d/;

                    if (urlPattern.test(this._url) && this._method.toUpperCase() === 'GET' && this._url != currentURL) {

                        currentURL = this._url
                        console.log(this._url);
                        const jsonData = JSON.parse(this.responseText);
                        console.log(jsonData);
                        currentData = jsonData
                        const status = JSON.parse(localStorage.getItem('status'));
                        console.log(status);
                        if (status) getData(jsonData);

                    }
                }
            });
            return originalSend.apply(this, arguments);
        };
    }

    function convertToCSV(jsonArray) {
        console.log(jsonArray);
        const headers = new Set();
        jsonArray.forEach(obj => Object.keys(obj).forEach(key => headers.add(key)));
        const headerArray = Array.from(headers);

        const csvRows = [];
        csvRows.push(headerArray.join(','));

        jsonArray.forEach(obj => {
            const row = headerArray.map(header => {
                const cell = obj[header] !== undefined ? obj[header] : '';
                return `"${cell}"`;
            });
            csvRows.push(row.join(','));
        });

        return csvRows.join('\n');
    }

    async function jsonToCsv() {
        const fullData = JSON.parse(localStorage.getItem('fullData'));
        console.log(fullData);
        if (fullData.length) {
            const csv = convertToCSV(fullData);
            const blob = new Blob([csv.replaceAll('★ ', '')], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            if (link.download !== undefined) {
                const url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', 'skinsmonkey.csv');
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }


    }

    function convertToTime(seconds) {
        const days = Math.floor(seconds / (24 * 60 * 60));
        seconds %= (24 * 60 * 60);
        const hours = Math.floor(seconds / (60 * 60));
        seconds %= (60 * 60);
        const minutes = Math.floor(seconds / 60);
        seconds %= 60;
        if (hours == 23) {
            return days + 1
        } else {
            return days
        }
        // return `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;
    }

    function convertToDollars(cents) {
        const dollars = cents / 100;
        return `$${dollars.toFixed(2)}`;
    }


    function checkUnit(selector) {
        return new Promise((resolve) => {
            const intervalId = setInterval(() => {
                if (document.querySelector(selector)) {
                    clearInterval(intervalId);
                    resolve(true);
                }
            }, 1000);
        });
    }
})();

