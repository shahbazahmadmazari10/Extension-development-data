// content.js (Example - This file will be registered as a content script)
console.log("Content script registered and running!");