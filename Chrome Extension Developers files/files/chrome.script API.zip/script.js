// script.js (Example - This file will be injected)
console.log("Script injected from file!");