(async () => {
    // const { fullData } = await chrome.storage.local.get('fullData')

    // console.log(fullData);


    const { status } = await chrome.storage.local.get('status')

    if (status) {
        document.querySelector('#start_button').setAttribute('disabled', true)
        document.querySelector('#stop_button').removeAttribute('disabled')
    } else {
        document.querySelector('#start_button').removeAttribute('disabled')
        document.querySelector('#stop_button').setAttribute('disabled', true)
    }

    setInterval(async () => {
        const { status } = await chrome.storage.local.get('status')
        if (status) {
            const { count } = await chrome.storage.local.get('count');
            document.getElementById("success").innerText = count;
        }
    }, 500)

    document.querySelector('#start_button').addEventListener('click', (e) => {
        console.log('clcik');



        chrome.storage.local.set({ count: 0 })
        chrome.storage.local.set({ fullCount: 0 })


        chrome.storage.local.set({ status: true })

        document.querySelector('#start_button').setAttribute('disabled', true)
        document.querySelector('#stop_button').removeAttribute('disabled')

        chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {
            var activeTab = tabs[0];
            chrome.tabs.sendMessage(activeTab.id, { "message": "start" }).catch(console.log);
        });


    })

    document.querySelector('#stop_button').addEventListener('click', async (e) => {
        console.log('stopped clicked');
        e.target.setAttribute('disabled', true);
        document.querySelector('#start_button').removeAttribute('disabled')

        chrome.storage.local.set({ status: false })
        // jsonToCsv()
        // setTimeout(() => {
        //     chrome.storage.local.set({ status: false });
        //     chrome.storage.local.set({ fullData: [] });
        //     chrome.storage.local.set({ count: 0 })
        // }, 1000);



    })

    document.querySelector('#download_button').addEventListener('click', async (e) => {
        jsonToCsv()
    })

    function convertToCSV(data) {
        const header = ['Manager', 'Phone', 'Email', 'Link'];
        const rows = data.map(item => [
            item.Manager,
            item.Phone,
            item.Email,
            item.Link
        ]);

        // Create CSV string
        const csv = [header.join(','), ...rows.map(row => row.map(value => `"${value}"`).join(','))].join('\n');
        return csv;
    }

    // Trigger CSV download
    async function jsonToCsv() {
        const { fullData } = await chrome.storage.local.get('fullData')

        console.log(fullData);
        const csv = convertToCSV(fullData);
        const csvBlob = new Blob([csv], { type: 'text/csv;' });
        const url = URL.createObjectURL(csvBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'data.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }








})()







