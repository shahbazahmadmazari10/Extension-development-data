let imagesData = undefined
chrome.runtime.onMessage.addListener(async function (request, sender, sendResponse) {
    console.log(request);
    if (request.message == 'start') {
        const systemDate = new Date();
        const targetDate = new Date("2025-02-15");

        // if (systemDate < targetDate) {
        imagesData = await getData()
        console.log(imagesData);
        const image = imagesData.shift()
        console.log(image);
        post(image);
        // }
    }

});

async function post(image) {
    const postButton = document.querySelector('[aria-label="Column body"]')?.querySelectorAll('div[aria-label*="compose "]')[0]?.parentElement?.querySelectorAll('[role="button"]')[1]
    postButton.click()
    // await new Promise((rs, rj) => setTimeout(rs, 1000))
    // postButton.click()
    await checkElement('[role="dialog"] [role="textbox"]')
    const inputTextField = document.querySelector('[role="dialog"] [role="textbox"]')
    pasteText(inputTextField, image['Caption'])



    const uploaded = await uploadImageFromLink(image['Image Name'])
    console.log(uploaded);
    if (uploaded) {


        await checkElement('[role="dialog"] picture img')
        console.log('uploaded');
        await new Promise((rs, rj) => setTimeout(rs, 2000))

        document.querySelectorAll('[role="dialog"] [role="button"]').forEach(e => {
            if (e.innerText == 'Post') {
                console.log(e)
                e.click()
            }
        })

        await new Promise((rs, rj) => setTimeout(rs, 1000))

        await checkElementPosted('ul>li')
        console.log('removed');
        await new Promise((rs, rj) => setTimeout(rs, 3000))

        document.querySelector('[data-pressable-container="true"]>div [aria-label="Reply"]').parentElement?.parentElement?.parentElement?.click()
        await new Promise((rs, rj) => setTimeout(rs, 2000))
        pasteText(document.querySelector('[role="dialog"] [role="textbox"]'), image['Comment Link'])
        await new Promise((rs, rj) => setTimeout(rs, 500))
        document.querySelectorAll('[role="dialog"] [role="button"]').forEach(e => {
            if (e.innerText == 'Post') {
                console.log(e)
                e.click()
            }
        })
        await new Promise((rs, rj) => setTimeout(rs, 1000))
        await checkElementPosted('ul>li')
        console.log('commented');
        await new Promise((rs, rj) => setTimeout(rs, 1000))
        let { count } = await chrome.storage.local.get('count')
        count++
        chrome.storage.local.set({ count })

        console.log(imagesData)
        const data = imagesData.shift()
        console.log(data);

        if (data) {
            post(data)
        } else {
            chrome.storage.local.set({ status: false })
            alert('All images uploaded successfully')
        }

    } else {
        console.log('not uploaded moving next upload');
        document.querySelector('[role="dialog"] [role="button"]').click()
        await new Promise((rs, rj) => setTimeout(rs, 500))
        document.querySelectorAll('[role="dialog"] [role="button"]')?.forEach(e => {
            if (e.innerText == 'Discard') {
                console.log(e)
                e?.click()
            }
        })
        console.log(imagesData)
        const data = imagesData.shift()
        console.log(data);
        // await new Promise((rs, rj) => setTimeout(rs, 2000))

        if (data) {
            console.log('post this data');
            console.log(data);
            post(data)
        } else {
            chrome.storage.local.set({ status: false })
            alert('All images uploaded successfully')
        }
    }
}





async function getData() {
    try {
        const filePath = chrome.runtime.getURL("ImagesData.xlsx");
        console.log(filePath);

        // Fetch the file and convert it to an array buffer
        const response = await fetch(filePath);
        const data = await response.arrayBuffer();

        // Read the Excel workbook
        const workbook = XLSX.read(data, { type: "array" });

        // Assuming the first sheet contains the data
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const range = { s: { r: 0, c: 0 }, e: { r: 1300, c: 4 } };

        // Parse data from the worksheet
        let jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 2, range });
        console.log(jsonData);

        // Flatten and process the data
        jsonData = jsonData.flat(Infinity);
        console.log(jsonData);
        console.log(jsonData);

        return jsonData; // Return the processed data
    } catch (error) {
        console.error("Error loading the Excel file:", error);
    }
}

