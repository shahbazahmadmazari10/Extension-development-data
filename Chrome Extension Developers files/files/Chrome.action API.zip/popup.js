// Set a new icon
document.getElementById("setIcon").addEventListener("click", () => {
    chrome.action.setIcon({ path: "icons/icon_49.png" }, () => {
        console.log("Icon set to icon48.png");
    });
});

// Set badge text
document.getElementById("setBadgeColor").addEventListener("click", () => {
    chrome.action.setBadgeBackgroundColor({ color: "#00FF00" }, () => {
        console.log("Badge background color set to green (#00FF00).");
    });

});



document.getElementById("setBadgeColor").addEventListener("click", () => {
    chrome.action.setBadgeText({ text: "NEW" }, () => {
        console.log("Badge text set to NEW");
    });
});

// Get badge text
document.getElementById("getBadgeText").addEventListener("click", () => {
    chrome.action.getBadgeText({}, (text) => {
        console.log("Current badge text:", text);
        alert("Badge Text: " + text);
    });
});

// Enable the action
document.getElementById("enableAction").addEventListener("click", () => {
    chrome.action.enable(() => {
        console.log("Action enabled");
    });
});

// Disable the action
document.getElementById("disableAction").addEventListener("click", () => {
    chrome.action.disable(() => {
        console.log("Action disabled");
    });
});

// Check if the action is enabled
document.getElementById("checkEnabled").addEventListener("click", () => {
    chrome.action.isEnabled((isEnabled) => {
        console.log("Is Action Enabled?", isEnabled);
        alert("Is Enabled? " + isEnabled);
    });
});

// Get title of the action
document.getElementById("getTitle").addEventListener("click", () => {
    chrome.action.getTitle({}, (title) => {
        console.log("Current title:", title);
        alert("Title: " + title);
    });
});

// Get popup URL
document.getElementById("getPopup").addEventListener("click", () => {
    chrome.action.getPopup({}, (popupUrl) => {
        console.log("Current popup URL:", popupUrl);
        alert("Popup URL: " + popupUrl);
    });
});

// Get badge text color
document.getElementById("getBadgeTextColor").addEventListener("click", () => {
    chrome.action.getBadgeTextColor({}, (color) => {
        console.log("Badge Text Color:", color);
        alert("Badge Text Color: " + JSON.stringify(color));
    });
});
