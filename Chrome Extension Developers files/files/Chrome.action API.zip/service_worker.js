chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension installed");

    // Set default badge background color and text
    chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
    chrome.action.setBadgeText({ text: "Demo" });
    chrome.action.openPopup();
});

chrome.action.onClicked.addListener((tab) => {
    // Open the popup programmatically
    // chrome.action.openPopup();
    // console.log("Popup opened programmatically.");
    chrome.action.setBadgeBackgroundColor({ color: "#FF0099" });
    chrome.action.setBadgeText({ text: "clicked" });
});
